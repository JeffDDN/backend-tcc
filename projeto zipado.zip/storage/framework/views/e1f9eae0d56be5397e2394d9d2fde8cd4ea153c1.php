

<?php $__env->startSection('content'); ?>
    <div id="tabela">
        <div class="header">
            <h3>Qr code</h3>
        </div>
        <div id="qr-area">
            <img src="<?php echo e(route('gerarQR')); ?>" alt="" width="300px" height="300px">
            <!-- <img src="<?php echo e(url('public/assets/images/qrcode2.png')); ?>" alt="" width="260px" height="250px"> -->
        </div> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\backEnd\resources\views/qr_code.blade.php ENDPATH**/ ?>