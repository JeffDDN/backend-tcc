@extends('layouts.template')

@section('content')
    <div id="tabela">
        <div class="header">
            <h3>Lista de Presença</h3>
        </div>
        <div id="table">
            <table id="presenca" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Matrícula</th>
                        <th>Data</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>João Victor Barbosa de Melo</td>
                        <td>201904454546</td>
                        <td>13/06/2022</td>
                    </tr>
                    <tr>
                        <td>Jefferson Rodrigues Cardoso de Sousa</td>
                        <td>201902601602</td>
                        <td>13/06/2022</td>
                    </tr>
                    <tr>
                        <td>Alexandre Arauujo Farias</td>
                        <td>201998367219</td>
                        <td>13/06/2022</td>
                    </tr>
                </tbody>
            </table>
        </div> 
    </div> 
    
                
@endsection